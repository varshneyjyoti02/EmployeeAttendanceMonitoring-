import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/model/Employee';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { LoginModel } from 'src/model/LoginModel';

@Component({
  selector: 'app-employeelogin',
  templateUrl: './employeelogin.component.html',
  styleUrls: ['./employeelogin.component.css']
})
export class EmployeeloginComponent implements OnInit {
  login: Employee;
  password: any;
  userName: any;
  //employee: Employee;
  //logincheck: Employee;
  //employeecheck: Employee;
  //id: any;
  
  constructor(private router: Router, private service: EmployeeService) { 
    this.login = new Employee();
    this.userName = this.login.userName;
    this.password = this.login.password;
  }

  ngOnInit() {
  }

  getEmployeeLogin(){
    console.log("passing");
    this.service.getEmployeeLogin(this.login).subscribe(res=>{
      // this.logincheck = res;
      // var loginSuccesful = false;
      // console.log("passing");
      // if(this.userName === this.employee.userName && this.password === this.employee.password){
      //   loginSuccesful= true;
      //   this.router.navigate(['/employee']);
      // }
      // else {
      //   alert("Invalid Details.")
      // }
      // localStorage.setItem("employeeId":res.id)
      sessionStorage.setItem('id', res.id+"");
      alert("Login Successful")
      console.log(res);
      this.router.navigate(['/emp']);
      //replace your code here after succesfull login
    },err=>{
      console.log("Invalid Credentials");
      alert("Invalid Credentials.")
      //handle the error or invalid login
    })
  }

}

