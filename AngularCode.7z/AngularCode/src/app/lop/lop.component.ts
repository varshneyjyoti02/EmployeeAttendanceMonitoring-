import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';
import { Employee } from 'src/model/Employee';

@Component({
  selector: 'app-lop',
  templateUrl: './lop.component.html',
  styleUrls: ['./lop.component.css']
})
export class LopComponent implements OnInit {
  id: any;
  lop: any;
  //demo: number;
  employee: Employee;
  constructor(private router: Router, private service: EmployeeService) {
    this.employee = new Employee();
  }

  ngOnInit() {

    this.viewLop();
  }
  viewLop() {
    this.id = sessionStorage.getItem('id');
    console.log(this.id);
    this.service.viewLop(this.id).subscribe(res => {
      console.log("abcd");
      this.employee.id =this.id;
      this.employee.lop = res;
      //this.demo = res as number;
      console.log(this.employee.lop);

    })
  }


}


// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
// import { EmployeeService } from '../employee.service';
// import { AttendanceModel } from 'src/model/AttendanceModel';
// import { Observable } from 'rxjs';

// @Component({
//   selector: 'app-attendance',
//   templateUrl: './attendance.component.html',
//   styleUrls: ['./attendance.component.css']
// })
// export class AttendanceComponent implements OnInit {
// attendance: AttendanceModel;
// attendances: Observable<AttendanceModel[]>;
// // empId: any;
// // date: any;
// // status: any;
// id:any;

//   constructor(private router: Router, private service: EmployeeService) {
//       //  this.attendance = new AttendanceModel();
//       //  this.empId = this.attendance.empId;
//       //  this.date= this.attendance.date;
//       //  this.status = this.attendance.status;
//    }

//   ngOnInit() {
//     this.getEmployeeAttendance();
//   }

//   getEmployeeAttendance(){
//     this.id=sessionStorage.getItem('id');
//     console.log(this.id);
//     //console.log("abcd");
//     this.service.getEmployeeAttendance(this.id).subscribe(res=>
//       {
//          console.log("abcd");
//         //alert("Attendance dispayed")
//         console.log(res);

//       })

//   }

// }



