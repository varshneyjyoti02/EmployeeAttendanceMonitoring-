import { Injectable } from '@angular/core';
//import { HttpClient } from 'selenium-webdriver/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from 'src/model/Employee';
import { LoginModel } from 'src/model/LoginModel';
import { EmployeeloginComponent } from './employeelogin/employeelogin.component';
import { AttendanceModel } from 'src/model/AttendanceModel';
import { AttendanceComponent } from './attendance/attendance.component';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private baseUrl = 'http://localhost:8084';
  constructor(private http: HttpClient) { }


  getAdmin(): Observable<LoginModel[]> {
    return this.http.get<LoginModel[]>(this.baseUrl + '/login');
  }

  getEmployeeLogin(login: Employee): Observable<Employee> {
    let httpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "Cache-Control": "no-cache"
    })
    return this.http.post<Employee>(this.baseUrl + '/employeelogin', JSON.stringify(login), { headers: httpHeaders });
  }

  getEmployee1(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.baseUrl + '/getEmployee');
  }
  getEmployeesList(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.baseUrl + '/getall');
  }

  getEmployee(id: number) {
    return this.http.get(this.baseUrl + '/getById' + { id });
  }

  getEmployeeAttendance(id: number) {
    //return this.http.get(this.baseUrl + '/attendance' + { id });
    return this.http.get(`${this.baseUrl}/attendance/${id}`);
  }

  createEmployee(employee: Employee) {
    return this.http.post<Employee>(this.baseUrl + '/add', employee);
  }
  
  applyLeave(attendance: AttendanceModel) {
    let httpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "Cache-Control": "no-cache"
    })
    return this.http.post<AttendanceModel>(this.baseUrl + '/leave', JSON.stringify(attendance), { headers: httpHeaders });
  }

  applyLeave1(attendance: AttendanceModel) {
    console.log(attendance);
    return this.http.post<AttendanceModel>(`${this.baseUrl}/leave`, { responseType: 'JSON' });
  }

  viewLop(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/viewlop/${id}`);
  }


  updateEmployee(id: number, employee: Employee): Observable<Object> {
    return this.http.put(`${this.baseUrl}/update/${id}`, employee);
  }

  // deleteEmployee(id: number): Observable<any> {
  //   return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  // }

  deleteEmployee(id: number) {
    return this.http.delete(`${this.baseUrl}/delete/${id}`, { responseType: 'text' });
  }

  //   getEmployeesList(): Observable<any> {
  //     return this.http.get<>
  // }



}