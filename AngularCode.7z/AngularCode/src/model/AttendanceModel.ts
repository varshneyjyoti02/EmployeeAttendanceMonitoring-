import { Employee } from './Employee';

export class AttendanceModel{
    number: number;
    date: string;
    status: string;
    empId : number;
} 