export class Employee {
    id: number;
    name: string;
    salary: number;
    lop: number;
    active: boolean;
    userName: string;
    password: string;
    mobileNo: number;
}